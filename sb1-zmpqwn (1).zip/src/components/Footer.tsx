import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-100 text-gray-900 border-t border-gray-200">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-wrap justify-between">
          <div className="w-full md:w-1/3 mb-6 md:mb-0">
            <h3 className="text-lg font-semibold mb-2 font-['Playfair_Display']">Jok Cosmetics</h3>
            <p>Schönheit in Perfektion</p>
          </div>
          <div className="w-full md:w-1/3 mb-6 md:mb-0">
            <h3 className="text-lg font-semibold mb-2 font-['Playfair_Display']">Links</h3>
            <ul>
              <li><Link to="/impressum" className="hover:text-gray-600 transition duration-300">Impressum</Link></li>
              <li><Link to="/datenschutz" className="hover:text-gray-600 transition duration-300">Datenschutz</Link></li>
              <li><Link to="/agb" className="hover:text-gray-600 transition duration-300">AGB</Link></li>
            </ul>
          </div>
          <div className="w-full md:w-1/3">
            <h3 className="text-lg font-semibold mb-2 font-['Playfair_Display']">Folgen Sie uns</h3>
            <a href="https://www.instagram.com/jok_cosmetics" target="_blank" rel="noopener noreferrer" className="text-gray-900 hover:text-gray-600 transition duration-300">
              <Instagram className="inline-block mr-2" />
              Instagram
            </a>
          </div>
        </div>
        <div className="mt-8 text-center">
          <p>&copy; {new Date().getFullYear()} Jok Cosmetics. Alle Rechte vorbehalten.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;