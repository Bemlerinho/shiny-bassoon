import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-md' : 'bg-transparent'}`}>
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <Link to="/" className="text-2xl font-bold text-gray-900 font-['Playfair_Display']">
            Jok Cosmetics
          </Link>
          <nav className="hidden md:flex space-x-6">
            <Link to="/" className="text-gray-900 hover:text-gray-600 transition duration-300">Home</Link>
            <Link to="/about" className="text-gray-900 hover:text-gray-600 transition duration-300">Über uns</Link>
            <Link to="/treatments" className="text-gray-900 hover:text-gray-600 transition duration-300">Behandlungen</Link>
            <Link to="/gallery" className="text-gray-900 hover:text-gray-600 transition duration-300">Galerie</Link>
            <Link to="/image-gallery" className="text-gray-900 hover:text-gray-600 transition duration-300">Bildergalerie</Link>
            <Link to="/contact" className="text-gray-900 hover:text-gray-600 transition duration-300">Kontakt</Link>
          </nav>
          <a
            href="whatsapp://send?phone=491735390928"
            className="hidden md:inline-block btn btn-primary"
          >
            Jetzt Termin buchen
          </a>
          <div className="md:hidden">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X className="text-gray-900" /> : <Menu className="text-gray-900" />}
            </button>
          </div>
        </div>
      </div>
      {isMenuOpen && (
        <div className="md:hidden bg-white">
          <nav className="flex flex-col items-center py-4">
            <Link to="/" className="py-2 text-gray-900 hover:text-gray-600 transition duration-300">Home</Link>
            <Link to="/about" className="py-2 text-gray-900 hover:text-gray-600 transition duration-300">Über uns</Link>
            <Link to="/treatments" className="py-2 text-gray-900 hover:text-gray-600 transition duration-300">Behandlungen</Link>
            <Link to="/gallery" className="py-2 text-gray-900 hover:text-gray-600 transition duration-300">Galerie</Link>
            <Link to="/image-gallery" className="py-2 text-gray-900 hover:text-gray-600 transition duration-300">Bildergalerie</Link>
            <Link to="/contact" className="py-2 text-gray-900 hover:text-gray-600 transition duration-300">Kontakt</Link>
            <a
              href="whatsapp://send?phone=491735390928"
              className="mt-4 btn btn-primary"
            >
              Jetzt Termin buchen
            </a>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;