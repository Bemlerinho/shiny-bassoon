import React from 'react';
import ImageWithFallback from './ImageWithFallback';

const images = [
  { src: '/images/eyelash-closeup-1.jpg', alt: 'Bild 1 Beschreibung' },
  { src: '/images/eyelash-closeup-2.jpg', alt: 'Bild 2 Beschreibung' },
  { src: '/images/eyelash-closeup-3.jpg', alt: 'Bild 3 Beschreibung' },
  { src: '/images/lip-treatment.jpg', alt: 'Bild 4 Beschreibung' },
];

const ImageGallery: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold text-gray-900 mb-8 text-center">Bildergalerie</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
        {images.map((image, index) => (
          <div key={index} className="gallery-item">
            <ImageWithFallback
              src={image.src}
              alt={image.alt}
              fallbackSrc="/images/placeholder.jpg"
              className="w-full h-auto rounded-lg shadow-lg"
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default ImageGallery;