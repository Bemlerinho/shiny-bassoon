import React from 'react';

const AGB = () => {
  return (
    <div className="bg-white min-h-screen py-24">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-gray-900 mb-8 text-center animate-fadeInUp font-['Playfair_Display']">Allgemeine Geschäftsbedingungen</h1>
        
        <div className="prose max-w-none animate-fadeInUp">
          <h2>1. Geltungsbereich</h2>
          <p>
            Diese Allgemeinen Geschäftsbedingungen gelten für alle Verträge zwischen Jok Cosmetics, vertreten durch Thansuda-Daduang Bemler, Wilhelmstraße 17, 75378 Bad Liebenzell (nachfolgend "Anbieter") und ihren Kunden (nachfolgend "Kunde") in ihrer zum Zeitpunkt des Vertragsschlusses gültigen Fassung.
          </p>

          <h2>2. Vertragsschluss</h2>
          <p>
            Die Präsentation der Dienstleistungen auf unserer Website stellt kein bindendes Angebot dar. Erst die Buchung einer Dienstleistung durch den Kunden ist ein bindendes Angebot nach § 145 BGB. Der Anbieter kann dieses Angebot innerhalb von 5 Tagen annehmen.
          </p>

          <h2>3. Leistungsbeschreibung</h2>
          <p>
            Der Umfang der Leistungen ergibt sich aus der jeweiligen Beschreibung auf der Website oder aus den individuellen Vereinbarungen zwischen dem Anbieter und dem Kunden.
          </p>

          <h2>4. Preise und Zahlungsbedingungen</h2>
          <p>
            Alle Preise sind Endpreise und enthalten die gesetzliche Mehrwertsteuer. Die Zahlung erfolgt bar oder per EC-Karte direkt nach der Behandlung, sofern nicht anders vereinbart.
          </p>

          <h2>5. Terminvereinbarung und Stornierung</h2>
          <p>
            Termine können telefonisch, per WhatsApp oder über unser Online-Buchungssystem vereinbart werden. Bei Verhinderung bitten wir um rechtzeitige Absage, mindestens 24 Stunden vor dem vereinbarten Termin. Bei späteren Absagen oder Nichterscheinen behalten wir uns vor, eine Ausfallgebühr in Höhe von 50% des Behandlungspreises zu berechnen.
          </p>

          {/* Add more sections as needed */}

          <h2>10. Schlussbestimmungen</h2>
          <p>
            Es gilt das Recht der Bundesrepublik Deutschland unter Ausschluss des UN-Kaufrechts. Erfüllungsort und Gerichtsstand ist, soweit gesetzlich zulässig, der Sitz des Anbieters.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AGB;