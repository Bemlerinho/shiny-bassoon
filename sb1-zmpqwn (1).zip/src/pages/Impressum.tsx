import React from 'react';

const Impressum = () => {
  return (
    <div className="bg-white min-h-screen py-24">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-gray-900 mb-8 text-center animate-fadeInUp font-['Playfair_Display']">Impressum</h1>
        
        <div className="prose max-w-none animate-fadeInUp">
          <h2>Angaben gemäß § 5 TMG</h2>
          <p>
            Jok Cosmetics<br />
            Thansuda-Daduang Bemler<br />
            Wilhelmstraße 17<br />
            75378 Bad Liebenzell
          </p>

          <h2>Kontakt</h2>
          <p>
            Telefon: +49 173 5390928<br />
            E-Mail: kontakt@jokcosmetics.de
          </p>

          <h2>Umsatzsteuer-ID</h2>
          <p>
            Umsatzsteuer-Identifikationsnummer gemäß § 27 a Umsatzsteuergesetz:<br />
            [Ihre Umsatzsteuer-ID]
          </p>

          <h2>Berufsbezeichnung und berufsrechtliche Regelungen</h2>
          <p>
            Berufsbezeichnung: Kosmetikerin<br />
            Zuständige Kammer: [Name der zuständigen Kammer]<br />
            Verliehen in: Deutschland
          </p>

          <h2>Streitschlichtung</h2>
          <p>
            Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung (OS) bereit: https://ec.europa.eu/consumers/odr<br />
            Unsere E-Mail-Adresse finden Sie oben im Impressum.
          </p>

          <p>
            Wir sind nicht bereit oder verpflichtet, an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle teilzunehmen.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Impressum;