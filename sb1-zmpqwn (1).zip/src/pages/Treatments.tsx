import React from 'react';
import BookingButton from '../components/BookingButton';

const treatments = [
  {
    name: "Wimpernverlängerung",
    description: "Für einen unwiderstehlichen Augenaufschlag. Lass deine Wimpern dichter und länger aussehen, ganz natürlich.",
    image: "/images/eyelash-closeup-1.jpg"
  },
  {
    name: "Permanent Make-up",
    description: "Lang anhaltende Schönheit, jeden Tag. Von perfekt geformten Augenbrauen bis zu idealen Lippenkonturen.",
    image: "/images/lip-treatment.jpg"
  },
  {
    name: "Brow Lifting",
    description: "Betone deine Augenbrauen mit einer Lifting-Behandlung, die deine Augenpartie zum Strahlen bringt.",
    image: "/images/eyelash-closeup-2.jpg"
  },
  {
    name: "Microneedling",
    description: "Hautregeneration und Verjüngung. Microneedling fördert die Kollagenproduktion und sorgt für glatte Haut.",
    image: "/images/eyelash-closeup-3.jpg"
  },
  {
    name: "BB Glow",
    description: "Ein strahlender Teint durch semi-permanentes Make-up, das deinem Gesicht Frische und Glanz verleiht.",
    image: "/images/eyelash-closeup-4.jpg"
  }
];

const Treatments = () => {
  return (
    <div className="bg-white min-h-screen py-24">
      <div className="container">
        <h1 className="text-4xl font-bold text-gray-900 mb-8 animate-fadeInUp">Unsere Behandlungen</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {treatments.map((treatment, index) => (
            <div key={index} className="bg-gray-100 rounded-lg p-6 shadow-lg">
              <img src={treatment.image} alt={treatment.name} className="responsive-image rounded-lg mb-4" />
              <h3 className="text-xl font-bold mb-2">{treatment.name}</h3>
              <p>{treatment.description}</p>
            </div>
          ))}
        </div>
        <div className="mt-12">
          <BookingButton />
        </div>
      </div>
    </div>
  );
};

export default Treatments;