import React from 'react';

const BookingButton: React.FC<{ className?: string }> = ({ className }) => {
  const handleBooking = () => {
    window.open('whatsapp://send?phone=491735390928', '_blank');
  };

  return (
    <button
      onClick={handleBooking}
      className={`btn btn-primary ${className}`}
    >
      Jetzt Termin buchen
    </button>
  );
};

export default BookingButton;