import React from 'react';
import BookingButton from '../components/BookingButton';

const About = () => {
  return (
    <div className="bg-white min-h-screen py-24">
      <div className="container">
        <h1 className="text-4xl font-bold text-gray-900 mb-8 animate-fadeInUp">Über uns</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <img src="/images/eyelash-closeup-1.jpg" alt="Thansuda-Daduang Bemler" className="responsive-image rounded-lg shadow-lg" />
          <div className="text-left">
            <h2 className="text-2xl font-bold mb-4">Herzlich Willkommen bei Jok Cosmetics!</h2>
            <p className="mb-4">
              Ich bin Thansuda, 31 Jahre jung und seit 2022 deine Expertin für Wimpernverlängerungen. Mit viel Leidenschaft und Präzision habe ich mein Angebot im Jahr 2023 um weitere Beauty-Behandlungen erweitert und mein eigenes Studio im schönen Bad Liebenzell eröffnet.
            </p>
            <p className="mb-4">
              Mein größtes Ziel ist es, dass du dich bei mir nicht nur schön, sondern auch rundum wohl und selbstbewusst fühlst. Jede Behandlung beginnt mit einer persönlichen und ausführlichen Beratung, damit wir gemeinsam genau den Look kreieren, der perfekt zu dir passt.
            </p>
            <p>
              Ich freue mich schon sehr darauf, dich in meinem Studio begrüßen zu dürfen und deine natürliche Schönheit noch mehr zum Strahlen zu bringen!
            </p>
            <p className="mt-4 font-semibold">Deine Thansuda</p>
          </div>
        </div>
        <div className="mt-12">
          <BookingButton />
        </div>
      </div>
    </div>
  );
};

export default About;