import React from 'react';
import { MapPin, Phone, Clock, MessageCircle } from 'lucide-react';
import BookingButton from '../components/BookingButton';

const Contact = () => {
  return (
    <div className="bg-white min-h-screen py-24">
      <div className="container">
        <h1 className="text-4xl font-bold text-gray-900 mb-8 animate-fadeInUp">Kontakt</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <img src="/images/eyelash-closeup-5.jpg" alt="Jok Cosmetics Studio" className="responsive-image rounded-lg shadow-lg mb-4" />
            <div className="text-left">
              <p className="flex items-center mb-2"><MapPin className="mr-2" /> Wilhelmstraße 17, 75378 Bad Liebenzell</p>
              <p className="flex items-center mb-2"><Phone className="mr-2" /> +49 173 5390928</p>
              <p className="flex items-center mb-2"><MessageCircle className="mr-2" /> kontakt@jokcosmetics.de</p>
              <p className="flex items-center mb-2"><Clock className="mr-2" /> Montag - Samstag: 10:00 - 18:00 Uhr</p>
              <p className="mt-4">Termine nur nach Vereinbarung</p>
            </div>
          </div>
          <div>
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2635.202444621989!2d8.730660315674052!3d48.76543007927791!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4797b8e5e6e29b6f%3A0x41ffd3c8d098280f!2sWilhelmstra%C3%9Fe%2017%2C%2075378%20Bad%20Liebenzell%2C%20Germany!5e0!3m2!1sen!2sus!4v1620000000000!5m2!1sen!2sus"
              width="100%"
              height="450"
              style={{ border: 0 }}
              allowFullScreen={true}
              loading="lazy"
            ></iframe>
          </div>
        </div>
        <div className="mt-8">
          <BookingButton className="inline-flex items-center" />
        </div>
      </div>
    </div>
  );
};

export default Contact;