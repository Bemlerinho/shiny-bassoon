import React, { useState } from 'react';

const galleryImages = [
  '/images/halloween-special.jpg',
  '/images/eyelash-closeup-1.jpg',
  '/images/eyelash-closeup-2.jpg',
  '/images/lip-treatment.jpg',
  '/images/eyelash-closeup-3.jpg',
  '/images/eyelash-closeup-4.jpg',
  '/images/eyelash-closeup-5.jpg',
  '/images/eyelash-brow-1.jpg',
  '/images/eyelash-brow-2.jpg',
  '/images/eyelash-closeup-6.jpg'
];

const Gallery: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  return (
    <div className="bg-white min-h-screen py-24">
      <div className="container">
        <h1 className="text-4xl font-bold text-gray-900 mb-8 animate-fadeInUp">Unsere Galerie</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {galleryImages.map((image, index) => (
            <div key={index} className="relative overflow-hidden rounded-lg shadow-lg">
              <img
                src={image}
                alt={`Gallery image ${index + 1}`}
                className="w-full h-64 object-cover transition duration-300 ease-in-out transform hover:scale-110"
                onClick={() => setSelectedImage(image)}
              />
            </div>
          ))}
        </div>
      </div>
      {selectedImage && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50" onClick={() => setSelectedImage(null)}>
          <img src={selectedImage} alt="Selected gallery image" className="max-w-full max-h-full" />
        </div>
      )}
    </div>
  );
};

export default Gallery;