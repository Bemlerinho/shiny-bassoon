import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import BookingButton from '../components/BookingButton';

const backgroundImages = [
  '/images/eyelash-closeup-1.jpg',
  '/images/eyelash-closeup-2.jpg',
  '/images/eyelash-closeup-3.jpg'
];

const Home = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % backgroundImages.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-white text-gray-900">
      <div className="relative h-screen">
        <div className="absolute inset-0 w-full h-full">
          {backgroundImages.map((src, index) => (
            <img
              key={index}
              src={src}
              alt={`Background ${index + 1}`}
              className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${
                index === currentImageIndex ? 'opacity-100' : 'opacity-0'
              }`}
            />
          ))}
        </div>
        <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
          <div className="text-center animate-fadeInUp">
            <h1 className="text-5xl font-bold mb-4 text-white font-['Playfair_Display']">Jok Cosmetics</h1>
            <p className="text-xl mb-8 text-white">Schönheit in Perfektion</p>
            <div className="space-x-4">
              <Link
                to="/treatments"
                className="btn btn-primary"
              >
                Unsere Behandlungen
              </Link>
              <BookingButton />
            </div>
          </div>
        </div>
      </div>

      <div className="container py-16">
        <h2 className="text-3xl font-bold mb-8">Willkommen bei Jok Cosmetics</h2>
        <p className="mb-8">
          Entdecken Sie die Kunst der Schönheit in unserem exklusiven Beauty Studio in Bad Liebenzell.
          Wir bieten hochwertige Behandlungen, die Ihre natürliche Schönheit unterstreichen.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {backgroundImages.map((src, index) => (
            <img key={index} src={src} alt={`Cosmetic Work ${index + 1}`} className="responsive-image rounded-lg shadow-lg" />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Home;